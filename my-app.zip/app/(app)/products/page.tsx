"use client";

import { useDeferredValue, useEffect, useMemo, useState, type Key } from "react";
import { useSession } from "next-auth/react";
import { useSearchParams } from "next/navigation";
import {
  Alert,
  Button,
  Card,
  Form,
  Input,
  InputNumber,
  Modal,
  Popconfirm,
  Select,
  Table,
  Tag,
  Tooltip,
  Typography,
  message,
} from "antd";
import { CheckOutlined, DeleteOutlined, EditOutlined } from "@ant-design/icons";
import type { TableProps } from "antd";

type ProductStatus = "ACTIVE" | "INACTIVE" | "SOLD";

type Product = {
  id: string;
  name: string;
  sku: string;
  description?: string | null;
  price: number;
  quantity: number;
  status: ProductStatus;
  serialNumber: number;
  createdAt: string;
};

type EditableProduct = Product;

type ProductFormValues = {
  name: string;
  description?: string;
  price: number;
  quantity?: number;
  status?: ProductStatus;
};

const STATUS_COLOR: Record<ProductStatus, string> = {
  ACTIVE: "green",
  INACTIVE: "gold",
  SOLD: "red",
};

const productCardClass =
  "rounded-[24px] border border-border bg-surface shadow-none";

export default function ProductsPage() {
  const { data: session } = useSession();
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<EditableProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [form] = Form.useForm();
  const [editForm] = Form.useForm();
  const [sellForm] = Form.useForm();
  const [editing, setEditing] = useState<EditableProduct | null>(null);
  const [search, setSearch] = useState(searchParams.get("search") ?? "");
  const [addOpen, setAddOpen] = useState(false);
  const [sellOpen, setSellOpen] = useState(false);
  const [selling, setSelling] = useState<EditableProduct | null>(null);
  const deferredSearch = useDeferredValue(search);
  const [tableFilters, setTableFilters] = useState<Record<string, Key[] | null>>(
    {}
  );
  const [tableSorter, setTableSorter] = useState<{
    field?: string;
    order?: "ascend" | "descend";
  }>({});
  const rupee = String.fromCharCode(0x20b9);

  const userCode =
    session?.user?.role === "SHOPKEEPER" ? session.user.userCode : null;
  const shopName = session?.user?.name ?? "Shopkeeper";
  const shopPhone = session?.user?.phone ?? "XXXXXXXXXX";
  const shopAddress = session?.user?.address ?? "Address not set";
  const isShopkeeper = session?.user?.role === "SHOPKEEPER";
  const isFull = products.length >= 100;

  const fetchData = async () => {
    setLoading(true);
    const res = await fetch("/api/products");
    if (res.ok) {
      const data = await res.json();
      setProducts(
        [...data].sort((a, b) => a.serialNumber - b.serialNumber)
      );
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const nextSerialNumber = useMemo(() => {
    const max = products.reduce(
      (current, product) => Math.max(current, product.serialNumber),
      0
    );
    return max + 1;
  }, [products]);

  const sortBySerial = (items: EditableProduct[]) =>
    [...items].sort((a, b) => a.serialNumber - b.serialNumber);

  const nextCode = useMemo(() => {
    if (!userCode) return "--";
    return `${userCode}${String(nextSerialNumber).padStart(2, "0")}`;
  }, [nextSerialNumber, userCode]);

  const onCreate = async (values: ProductFormValues) => {
    if (isFull) {
      message.error("Inventory full (max 100 products)");
      return;
    }
    const quantity = Number(values.quantity ?? 0);
    const optimisticId = `temp-${Date.now()}`;
    const optimisticStatus = quantity === 0 ? "SOLD" : values.status ?? "ACTIVE";
    const optimisticProduct: EditableProduct = {
      id: optimisticId,
      name: values.name,
      sku: nextCode,
      description: values.description ?? null,
      price: Number(values.price),
      quantity,
      status: optimisticStatus,
      serialNumber: nextSerialNumber,
      createdAt: new Date().toISOString(),
    };
    const payload = {
      name: values.name,
      description: values.description,
      price: Number(values.price),
      quantity,
      status: values.status,
    };
    setProducts((prev) => sortBySerial([...prev, optimisticProduct]));
    form.resetFields();
    setAddOpen(false);
    const hide = message.loading("Creating product...", 0);
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const created = (await res.json()) as EditableProduct;
        message.success("Product created");
        setProducts((prev) =>
          sortBySerial(
            prev.map((item) => (item.id === optimisticId ? created : item))
          )
        );
      } else {
        const data = await res.json();
        message.error(data.error ?? "Unable to create product");
        setProducts((prev) => prev.filter((item) => item.id !== optimisticId));
      }
    } catch {
      message.error("Unable to create product");
      setProducts((prev) => prev.filter((item) => item.id !== optimisticId));
    } finally {
      hide();
    }
  };

  const openEdit = (record: EditableProduct) => {
    setEditing(record);
    editForm.setFieldsValue({
      name: record.name,
      description: record.description,
      price: record.price,
      quantity: record.quantity,
      status: record.status,
    });
  };

  const openSell = (record: EditableProduct) => {
    setSelling(record);
    setSellOpen(true);
    sellForm.setFieldsValue({ quantity: 1 });
  };

  const saveEdit = async () => {
    const values = (await editForm.validateFields()) as ProductFormValues;
    if (!editing) return;
    const prevRecord = editing;
    const nextQuantity = Number(values.quantity);
    const nextStatus = nextQuantity === 0 ? "SOLD" : values.status ?? editing.status;
    const optimistic: EditableProduct = {
      ...editing,
      name: values.name,
      description: values.description,
      price: Number(values.price),
      quantity: nextQuantity,
      status: nextStatus,
    };
    setEditing(null);
    setProducts((prev) =>
      sortBySerial(prev.map((item) => (item.id === optimistic.id ? optimistic : item)))
    );
    const hide = message.loading("Saving changes...", 0);
    try {
      const res = await fetch(`/api/products/${editing.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: values.name,
          description: values.description,
          price: Number(values.price),
          quantity: nextQuantity,
          status: values.status,
        }),
      });
      if (res.ok) {
        const updated = (await res.json()) as EditableProduct;
        message.success("Product updated");
        setProducts((prev) =>
          sortBySerial(
            prev.map((item) => (item.id === updated.id ? updated : item))
          )
        );
      } else {
        const data = await res.json();
        message.error(data.error ?? "Unable to update product");
        setProducts((prev) =>
          sortBySerial(
            prev.map((item) => (item.id === prevRecord.id ? prevRecord : item))
          )
        );
      }
    } catch {
      message.error("Unable to update product");
      setProducts((prev) =>
        sortBySerial(prev.map((item) => (item.id === prevRecord.id ? prevRecord : item)))
      );
    } finally {
      hide();
    }
  };

  const deleteRow = async (id: string) => {
    const removed = products.find((item) => item.id === id);
    if (editing?.id === id) {
      setEditing(null);
    }
    if (selling?.id === id) {
      setSellOpen(false);
      setSelling(null);
    }
    setProducts((prev) => prev.filter((item) => item.id !== id));
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (res.ok) {
        message.success("Product deleted");
      } else {
        const data = await res.json();
        message.error(data.error ?? "Unable to delete product");
        if (removed) {
          setProducts((prev) => sortBySerial([...prev, removed]));
        }
      }
    } catch {
      message.error("Unable to delete product");
      if (removed) {
        setProducts((prev) => sortBySerial([...prev, removed]));
      }
    }
  };

  const submitSell = async () => {
    const values = await sellForm.validateFields();
    if (!selling) return;
    const sellQty = Number(values.quantity ?? 0);
    const prevSelling = selling;
    setProducts((prev) =>
      prev.map((item) => {
        if (item.id !== selling.id) return item;
        const nextQty = Math.max(0, item.quantity - sellQty);
        const nextStatus = nextQty === 0 ? "SOLD" : item.status;
        return { ...item, quantity: nextQty, status: nextStatus };
      })
    );
    setSellOpen(false);
    setSelling(null);
    sellForm.resetFields();
    const hide = message.loading("Recording sale...", 0);
    try {
      const res = await fetch("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: selling.id, quantity: sellQty }),
      });
      if (res.ok) {
        message.success("Sale recorded");
      } else {
        const data = await res.json();
        message.error(data.error ?? "Unable to record sale");
        setProducts((prev) =>
          prev.map((item) => (item.id === prevSelling.id ? prevSelling : item))
        );
      }
    } catch {
      message.error("Unable to record sale");
      setProducts((prev) =>
        prev.map((item) => (item.id === prevSelling.id ? prevSelling : item))
      );
    } finally {
      hide();
    }
  };

  const filteredProducts = useMemo(() => {
    const term = deferredSearch.trim();
    if (!term) return products;

    const numeric = Number(term.replace(/,/g, ""));
    const isNumeric =
      !Number.isNaN(numeric) && /^[\d,]+(\.\d+)?$/.test(term);
    const upper = term.toUpperCase();
    const exactCode = products.find(
      (product) => product.sku.toUpperCase() === upper
    );

    if (exactCode) {
      if (exactCode.quantity > 0) {
        return [exactCode];
      }
      const targetPrice = Number(exactCode.price);
      if (Number.isFinite(targetPrice) && targetPrice > 0) {
        const min = targetPrice * 0.9;
        const max = targetPrice * 1.2;
        const alternatives = products.filter(
          (product) =>
            product.quantity > 0 &&
            Number(product.price) >= min &&
            Number(product.price) <= max
        );
        if (alternatives.length) {
          return [exactCode, ...alternatives];
        }
      }
      return [exactCode];
    }

    if (isNumeric) {
      const exactPriceAll = products.filter(
        (product) => Number(product.price) === numeric
      );
      const exactPriceInStock = exactPriceAll.filter(
        (product) => product.quantity > 0
      );
      if (exactPriceInStock.length) {
        return exactPriceInStock;
      }
      const min = numeric * 0.9;
      const max = numeric * 1.2;
      return products.filter(
        (product) =>
          product.quantity > 0 &&
          Number(product.price) >= min &&
          Number(product.price) <= max
      );
    }

    const lowerTerm = term.toLowerCase();
    const upperTerm = term.toUpperCase();
    return products.filter((product) => {
      const skuMatch = product.sku.toUpperCase().includes(upperTerm);
      const haystack = `${product.name} ${product.description ?? ""}`.toLowerCase();
      return skuMatch || haystack.includes(lowerTerm);
    });
  }, [products, deferredSearch]);

  const handleTableChange: TableProps<EditableProduct>["onChange"] = (
    _pagination,
    filters,
    sorter
  ) => {
    setTableFilters(filters as Record<string, Key[] | null>);
    if (!Array.isArray(sorter)) {
      setTableSorter({
        field: (sorter.field as string | undefined) ?? undefined,
        order: sorter.order ?? undefined,
      });
    }
  };

  const clearTableSortFilter = () => {
    setTableFilters({});
    setTableSorter({});
  };

  const copyWhatsapp = async (product: Product) => {
    const messageText = `✨ *${product.name}* ✨
  
  🆔 *Product Code:* ${product.sku}
  📝 *Details:*
  ${product.description ?? "-"}
  💰 *Price:* ${rupee}${Number(product.price).toLocaleString("en-IN")}
  📦 *Stock:* ${product.quantity > 0 ? "✅ Available" : "❌ Sold Out"}
  
  👉 *Reply "YES" to Buy*
  
  ━━━━━━━━━━━━━━━
  🏪 *${shopName}*
  📞 ${shopPhone}
  📍 ${shopAddress}
  ━━━━━━━━━━━━━━━`;
    try {
      await navigator.clipboard.writeText(messageText);
      message.success("WhatsApp message copied");
    } catch {
      message.error("Unable to copy message");
    }
  };

  return (
    <div className="space-y-6">
      {!isShopkeeper ? (
        <Alert
          type="warning"
          message="Shopkeeper access only"
          description="Admins manage shopkeepers and app settings only."
        />
      ) : null}

      {!userCode ? (
        <Alert
          type="warning"
          message="User code required"
          description="Ask the admin to set your user code before adding products."
        />
      ) : null}

      {isFull ? (
        <Alert
          type="error"
          message="Inventory full"
          description="You have reached the maximum limit of 100 products. Delete some items to add more."
          showIcon
        />
      ) : null}

      <Card className={productCardClass}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <Typography.Title level={4} className="!mb-1">
              Products
            </Typography.Title>
            <Typography.Text className="text-[color:var(--color-muted)]">
              Add new products, track stock, and share details fast.
            </Typography.Text>
          </div>
          <div className="w-full sm:w-auto">
            <Button
              type="primary"
              size="large"
              onClick={() => setAddOpen(true)}
              disabled={!userCode || isFull}
              className="w-full sm:w-auto"
            >
              Add Product
            </Button>
          </div>
        </div>
        <div className="mt-5 max-w-xl">
          <Input.Search
            placeholder="Search by Product Code / Name / Price / Keyword"
            size="large"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            allowClear
          />
        </div>
      </Card>

      <Card
        title="Product List"
        className={productCardClass}
        bodyStyle={{ paddingTop: 18 }}
        extra={
          <div className="hidden sm:flex gap-2">
            <Button onClick={clearTableSortFilter} disabled={loading}>
              Clear Sort & Filters
            </Button>
            <Button onClick={fetchData} loading={loading}>
              Refresh
            </Button>
          </div>
        }
      >
        <div className="sm:hidden mb-4 flex gap-2">
          <Button onClick={clearTableSortFilter} disabled={loading} className="flex-1">
            Clear
          </Button>
          <Button onClick={fetchData} loading={loading} className="flex-1">
            Refresh
          </Button>
        </div>
        <Table
          className="invent-table"
          dataSource={filteredProducts}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 20 }}
          onChange={handleTableChange}
          scroll={{ x: 800 }}
          columns={[
            {
              title: "Product Code",
              dataIndex: "sku",
              sorter: (a, b) => a.sku.localeCompare(b.sku),
              sortOrder:
                tableSorter.field === "sku" ? tableSorter.order : undefined,
            },
            {
              title: "Name",
              dataIndex: "name",
              sorter: (a, b) => a.name.localeCompare(b.name),
              sortOrder:
                tableSorter.field === "name" ? tableSorter.order : undefined,
            },
            {
              title: "Price",
              dataIndex: "price",
              render: (value) => `${rupee}${Number(value).toLocaleString("en-IN")}`,
              sorter: (a, b) => Number(a.price) - Number(b.price),
              sortOrder:
                tableSorter.field === "price" ? tableSorter.order : undefined,
            },
            {
              title: "Qty",
              dataIndex: "quantity",
              render: (value) => (
                <Tag color={value < 5 ? "volcano" : "blue"}>{value}</Tag>
              ),
              sorter: (a, b) => a.quantity - b.quantity,
              filters: [
                { text: "Low Stock (<5)", value: "LOW" },
                { text: "In Stock", value: "IN" },
                { text: "Out of Stock", value: "OUT" },
              ],
              filteredValue: tableFilters.quantity ?? null,
              onFilter: (value, record) => {
                if (value === "LOW") return record.quantity > 0 && record.quantity < 5;
                if (value === "OUT") return record.quantity === 0;
                if (value === "IN") return record.quantity > 0;
                return true;
              },
              sortOrder:
                tableSorter.field === "quantity"
                  ? tableSorter.order
                  : undefined,
            },
            {
              title: "Status",
              dataIndex: "status",
              render: (value: ProductStatus, record) => {
                const finalStatus = record.quantity === 0 ? "SOLD" : value;
                return (
                  <Tag color={STATUS_COLOR[finalStatus]}>{finalStatus}</Tag>
                );
              },
              filters: [
                { text: "Active", value: "ACTIVE" },
                { text: "Inactive", value: "INACTIVE" },
                { text: "Sold", value: "SOLD" },
              ],
              filteredValue: tableFilters.status ?? null,
              onFilter: (value, record) => {
                const finalStatus = record.quantity === 0 ? "SOLD" : record.status;
                return finalStatus === value;
              },
              sorter: (a, b) => {
                const aStatus = a.quantity === 0 ? "SOLD" : a.status;
                const bStatus = b.quantity === 0 ? "SOLD" : b.status;
                return aStatus.localeCompare(bStatus);
              },
              sortOrder:
                tableSorter.field === "status" ? tableSorter.order : undefined,
            },
            {
              title: "Action",
              render: (_, record) => (
                <div className="flex flex-wrap gap-2">
                  <Tooltip title="Edit">
                    <Button
                      aria-label="Edit product"
                      icon={<EditOutlined />}
                      onClick={() => openEdit(record)}
                    />
                  </Tooltip>
                  <Button onClick={() => openSell(record)}>Sell</Button>
                  <Button
                    onClick={() => copyWhatsapp(record)}
                    className="flex h-auto items-center gap-2 rounded-xl border-border bg-surface px-3 py-1.5 text-foreground shadow-none transition-all hover:border-brand/40 hover:bg-surface-muted"
                  >
                    <div className="flex h-5 w-5 items-center justify-center rounded-full bg-[#25D366]">
                      <CheckOutlined className="text-[10px] text-white" />
                    </div>
                    <span className="font-medium text-foreground">WhatsApp</span>
                  </Button>
                  <Popconfirm
                    title="Delete product?"
                    description="This will permanently remove the item from inventory."
                    onConfirm={() => deleteRow(record.id)}
                    okText="Yes"
                    cancelText="No"
                  >
                    <Tooltip title="Delete">
                      <Button
                        danger
                        aria-label="Delete product"
                        icon={<DeleteOutlined />}
                      />
                    </Tooltip>
                  </Popconfirm>
                </div>
              ),
            },
          ]}
        />
      </Card>

      <Modal
        open={!!editing}
        onCancel={() => setEditing(null)}
        onOk={saveEdit}
        title="Edit Product"
      >
        <Form layout="vertical" form={editForm}>
          <Form.Item label="Product Name" name="name" rules={[{ required: true }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Description" name="description">
            <Input.TextArea autoSize={{ minRows: 2, maxRows: 4 }} />
          </Form.Item>
          <Form.Item label="Price" name="price" rules={[{ required: true }]}>
            <InputNumber min={0} className="w-full" />
          </Form.Item>
          <Form.Item label="Quantity" name="quantity" rules={[{ required: true }]}>
            <InputNumber min={0} className="w-full" />
          </Form.Item>
          <Form.Item label="Status" name="status">
            <Select
              options={[
                { label: "Active", value: "ACTIVE" },
                { label: "Inactive", value: "INACTIVE" },
                { label: "Sold", value: "SOLD" },
              ]}
            />
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        open={addOpen}
        onCancel={() => setAddOpen(false)}
        onOk={() => form.submit()}
        title="Add Product"
      >
        <Form layout="vertical" form={form} onFinish={onCreate}>
          <div className="grid gap-4 md:grid-cols-2">
            <Form.Item label="Product Code">
              <Input value={nextCode} readOnly />
            </Form.Item>
            <Form.Item label="Status" name="status" initialValue="ACTIVE">
              <Select
                options={[
                  { label: "Active", value: "ACTIVE" },
                  { label: "Inactive", value: "INACTIVE" },
                ]}
              />
            </Form.Item>
          </div>
          <Form.Item
            label="Product Name"
            name="name"
            rules={[{ required: true }]}
          >
            <Input placeholder="DELL LAPTOP" />
          </Form.Item>
          <Form.Item label="Description" name="description">
            <Input.TextArea autoSize={{ minRows: 3, maxRows: 6 }} />
          </Form.Item>
          <div className="grid gap-4 md:grid-cols-2">
            <Form.Item label="Price" name="price" rules={[{ required: true }]}>
              <InputNumber min={0} className="w-full" />
            </Form.Item>
            <Form.Item label="Quantity" name="quantity" initialValue={1}>
              <InputNumber min={0} className="w-full" />
            </Form.Item>
          </div>
        </Form>
      </Modal>

      <Modal
        open={sellOpen}
        onCancel={() => setSellOpen(false)}
        onOk={submitSell}
        title="Create Sale"
      >
        <Form layout="vertical" form={sellForm}>
          <Form.Item label="Product">
            <Input value={selling?.name ?? ""} readOnly />
          </Form.Item>
          <Form.Item label="Available Quantity">
            <Input value={selling?.quantity ?? 0} readOnly />
          </Form.Item>
          <Form.Item
            label="Quantity Sold"
            name="quantity"
            rules={[
              { required: true, message: "Enter quantity" },
              {
                validator: (_, value) => {
                  if (!selling) return Promise.resolve();
                  if (value <= 0) return Promise.reject(new Error("Must be greater than 0"));
                  if (value > selling.quantity) {
                    return Promise.reject(
                      new Error("Cannot exceed available quantity")
                    );
                  }
                  return Promise.resolve();
                },
              },
            ]}
          >
            <InputNumber min={1} className="w-full" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
