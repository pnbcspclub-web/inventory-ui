"use client";

import { SessionProvider } from "next-auth/react";
import { ThemeProvider } from "@/components/theme-provider";
import AntdRegistry from "@/components/antd-registry";

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <AntdRegistry>
        <ThemeProvider>{children}</ThemeProvider>
      </AntdRegistry>
    </SessionProvider>
  );
}
