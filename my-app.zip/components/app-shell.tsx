"use client";

import { useMemo, useState } from "react";
import { Layout, Menu, Typography, Button, Dropdown, Modal, Input, Badge, Avatar } from "antd";
import {
  AppstoreOutlined,
  TeamOutlined,
  SettingOutlined,
  AlertOutlined,
  DownOutlined,
  PlusCircleOutlined,
  ClockCircleOutlined,
  BellOutlined,
  MoonOutlined,
  SunOutlined,
  SearchOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { signOut } from "next-auth/react";
import { useTheme } from "@/components/theme-provider";

const { Header, Content, Sider } = Layout;

type AppShellProps = {
  children: React.ReactNode;
  user: {
    name?: string | null;
    email?: string | null;
    role?: string | null;
    address?: string | null;
    phone?: string | null;
    shopName?: string | null;
  };
  appName: string;
};

export default function AppShell({ children, user, appName }: AppShellProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const isAdmin = user.role === "ADMIN";
  const [profileOpen, setProfileOpen] = useState(false);
  const { mode: themeMode, toggle } = useTheme();
  const mode = searchParams.get("mode");
  const filter = searchParams.get("filter");

  const activeKey = useMemo(() => {
    if (!isAdmin) return pathname;
    if (pathname !== "/admin/users") return pathname;
    if (mode === "create") return "/admin/users?mode=create";
    if (filter === "expiring") return "/admin/users?filter=expiring";
    return "/admin/users";
  }, [filter, isAdmin, mode, pathname]);

  const items = useMemo(
    () =>
      isAdmin
        ? [
            {
              key: "/admin/dashboard",
              icon: <AppstoreOutlined />,
              label: <Link href="/admin/dashboard">Dashboard</Link>,
            },
            {
              key: "/admin/users",
              icon: <TeamOutlined />,
              label: <Link href="/admin/users">All Users</Link>,
            },
            {
              key: "/admin/users?mode=create",
              icon: <PlusCircleOutlined />,
              label: <Link href="/admin/users?mode=create">Create New User</Link>,
            },
            {
              key: "/admin/users?filter=expiring",
              icon: <ClockCircleOutlined />,
              label: (
                <Link href="/admin/users?filter=expiring&days=2">
                  Expiring Users
                </Link>
              ),
            },
            {
              key: "/admin/notifications",
              icon: <BellOutlined />,
              label: <Link href="/admin/notifications">Notifications</Link>,
            },
            {
              key: "/admin/settings",
              icon: <SettingOutlined />,
              label: <Link href="/admin/settings">App Settings</Link>,
            },
          ]
        : [
            {
              key: "/dashboard",
              icon: <AppstoreOutlined />,
              label: <Link href="/dashboard">Dashboard</Link>,
            },
            {
              key: "/products",
              icon: <AlertOutlined />,
              label: <Link href="/products">Inventory</Link>,
            },
            {
              key: "/insights",
              icon: <ClockCircleOutlined />,
              label: <Link href="/insights">Insights</Link>,
            },
            {
              key: "/settings",
              icon: <SettingOutlined />,
              label: <Link href="/settings">Settings</Link>,
            },
          ],
    [isAdmin]
  );

  const shopTitle = user.shopName ?? user.name ?? "Shop";
  const shopInitials = shopTitle
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const menuItems = [
    {
      key: "profile",
      label: "Profile",
      onClick: () => setProfileOpen(true),
    },
    {
      key: "signout",
      label: "Sign out",
      onClick: () => signOut({ callbackUrl: "/login" }),
    },
  ];

  return (
    <Layout className="min-h-screen">
      <Sider
        width={252}
        breakpoint="lg"
        collapsedWidth={0}
        theme="light"
        className="app-sider"
      >
        <div className="flex h-full flex-col">
          <div className="flex items-center gap-3 p-6">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-brand text-sm font-bold text-white">
              {appName[0]}
            </div>
            <div className="overflow-hidden">
              <div className="truncate text-sm font-bold uppercase tracking-wide text-foreground">
                {appName}
              </div>
              <div className="truncate text-[10px] uppercase tracking-wider text-muted">
                Powered by Nexorva
              </div>
            </div>
          </div>

          <Menu
            mode="inline"
            selectedKeys={[activeKey]}
            items={items}
            className="flex-1"
          />

          <div className="p-4 border-t border-border">
            <Button
              className="w-full justify-start gap-2"
              type="text"
              icon={<LogoutOutlined />}
              onClick={() => signOut({ callbackUrl: "/login" })}
            >
              Sign Out
            </Button>
          </div>
        </div>
      </Sider>

      <Layout>
        <Header className="flex justify-between items-center bg-surface px-6 border-b border-border">
          <div className="flex items-center gap-4">
            <Typography.Text strong className="text-muted hidden sm:inline uppercase text-xs tracking-widest">
              {isAdmin ? "Admin Control" : "Shop Terminal"}
            </Typography.Text>
            {!isAdmin && (
              <Input
                placeholder="Search..."
                prefix={<SearchOutlined className="text-muted" />}
                className="max-w-[200px] bg-background border-none rounded-full"
              />
            )}
          </div>

          <div className="flex items-center gap-3">
            {isAdmin && (
              <Button
                type="text"
                icon={themeMode === "dark" ? <SunOutlined /> : <MoonOutlined />}
                onClick={toggle}
              />
            )}
            <Badge dot color="#22c55e" offset={[-2, 32]}>
              <Dropdown menu={{ items: menuItems }} placement="bottomRight" trigger={["click"]}>
                <div className="flex items-center gap-2 cursor-pointer hover:bg-surface-muted p-1 px-2 rounded-lg transition-colors">
                  <Avatar className="bg-brand text-white font-bold" size={32}>
                    {shopInitials}
                  </Avatar>
                  <div className="hidden md:block text-left leading-tight">
                    <div className="text-xs font-bold text-foreground">
                      {user.name}
                    </div>
                    <div className="text-[10px] text-accent">
                      Available Online
                    </div>
                  </div>
                  <DownOutlined className="text-[10px] text-muted" />
                </div>
              </Dropdown>
            </Badge>
          </div>
        </Header>

        <Content className="overflow-auto bg-background p-6">
          {children}
        </Content>
      </Layout>

      <Modal
        open={profileOpen}
        onCancel={() => setProfileOpen(false)}
        footer={null}
        title="Account Profile"
      >
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-muted uppercase tracking-wider mb-1">Name</div>
              <div className="font-semibold">{user.name ?? "User"}</div>
            </div>
            <div>
              <div className="text-xs text-muted uppercase tracking-wider mb-1">Role</div>
              <div className="font-semibold">{user.role ?? "SHOPKEEPER"}</div>
            </div>
          </div>
          <div>
            <div className="text-xs text-muted uppercase tracking-wider mb-1">Email</div>
            <div className="font-semibold">{user.email ?? "--"}</div>
          </div>
          {user.shopName && (
            <div>
              <div className="text-xs text-muted uppercase tracking-wider mb-1">Shop Name</div>
              <div className="font-semibold">{user.shopName}</div>
            </div>
          )}
        </div>
      </Modal>
    </Layout>
  );
}
